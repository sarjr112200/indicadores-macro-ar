"""Carga: base SQLite con vistas analíticas + CSV para Power BI."""
from __future__ import annotations

import sqlite3
from pathlib import Path

import pandas as pd

DIR_SQL = Path(__file__).resolve().parents[2] / "sql"
VISTAS = ["v_resumen_anual", "v_top3_meses_inflacion", "v_tc_vs_inflacion"]


def guardar_sqlite(df: pd.DataFrame, ruta: str | Path) -> sqlite3.Connection:
    con = sqlite3.connect(ruta)
    salida = df.copy()
    salida["fecha"] = salida["fecha"].dt.strftime("%Y-%m-%d")
    salida.to_sql("indicadores_mensuales", con, if_exists="replace", index=False)
    con.executescript((DIR_SQL / "vistas.sql").read_text(encoding="utf-8"))
    con.commit()
    return con


def consultar(con: sqlite3.Connection, vista: str) -> pd.DataFrame:
    if vista not in VISTAS:
        raise KeyError(f"Vista desconocida: {vista}")
    return pd.read_sql_query(f"SELECT * FROM {vista}", con)


def exportar_csv(con: sqlite3.Connection, destino: str | Path) -> list[Path]:
    destino = Path(destino)
    destino.mkdir(parents=True, exist_ok=True)
    archivos = []
    for nombre in ["indicadores_mensuales", *VISTAS]:
        ruta = destino / f"{nombre}.csv"
        pd.read_sql_query(f"SELECT * FROM {nombre}", con).to_csv(ruta, index=False)
        archivos.append(ruta)
    return archivos
