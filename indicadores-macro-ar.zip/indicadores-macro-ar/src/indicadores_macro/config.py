"""Series de la API de Series de Tiempo del Estado argentino (datos.gob.ar).

Los IDs se pueden buscar y verificar en https://datos.gob.ar/series
"""

API_URL = "https://apis.datos.gob.ar/series/api/series/"

SERIES = {
    # IPC Nacional, nivel general (INDEC, base dic-2016 = 100), mensual
    "ipc": "148.3_INIVELNAL_DICI_M_26",
    # Tipo de cambio de referencia Com. A3500 (BCRA), diario -> promedio mensual
    "tipo_cambio": "168.1_T_CAMBIOR_D_0_0_26",
    # EMAE (estimador mensual de actividad económica, INDEC), original
    "emae": "143.3_NO_PR_2004_A_21",
}

FECHA_DESDE = "2017-01-01"
