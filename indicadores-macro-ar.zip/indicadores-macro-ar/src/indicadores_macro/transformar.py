"""Transformación: limpieza, validación y cálculo de indicadores derivados."""
from __future__ import annotations

import pandas as pd

COLUMNAS_SERIES = ["ipc", "tipo_cambio", "emae"]


def limpiar(df: pd.DataFrame) -> pd.DataFrame:
    """Tipos correctos, fechas a inicio de mes, sin duplicados ni filas vacías."""
    df = df.copy()
    df["fecha"] = pd.to_datetime(df["fecha"], errors="coerce").dt.to_period("M").dt.to_timestamp()
    df = df.dropna(subset=["fecha"])
    for col in COLUMNAS_SERIES:
        df[col] = pd.to_numeric(df[col], errors="coerce")
        df.loc[df[col] <= 0, col] = pd.NA  # un índice o un precio no puede ser <= 0
    df = (df.dropna(subset=COLUMNAS_SERIES, how="all")
            .drop_duplicates(subset="fecha", keep="last")
            .sort_values("fecha"))
    # Completa meses faltantes como NaN para que los cálculos interanuales no se corran
    calendario = pd.date_range(df["fecha"].min(), df["fecha"].max(), freq="MS")
    return df.set_index("fecha").reindex(calendario).rename_axis("fecha").reset_index()


def validar(df: pd.DataFrame) -> list[str]:
    """Devuelve una lista de advertencias de calidad de datos (vacía = OK)."""
    problemas = []
    if df["fecha"].duplicated().any():
        problemas.append("Hay fechas duplicadas")
    saltos = df["fecha"].diff().dropna().dt.days
    if (saltos > 31).any():
        problemas.append("Faltan meses en la serie")
    for col in COLUMNAS_SERIES:
        nulos = int(df[col].isna().sum())
        if nulos:
            problemas.append(f"{col}: {nulos} valores faltantes")
    return problemas


def _var_pct(serie: pd.Series, periodos: int) -> pd.Series:
    return ((serie / serie.shift(periodos) - 1) * 100).round(2)


def calcular_indicadores(df: pd.DataFrame) -> pd.DataFrame:
    """Agrega variaciones mensuales, interanuales, acumuladas y tipo de cambio real."""
    df = df.copy()
    df["anio"] = df["fecha"].dt.year
    df["mes"] = df["fecha"].dt.month

    # Inflación
    df["ipc_var_mensual"] = _var_pct(df["ipc"], 1)
    df["ipc_var_interanual"] = _var_pct(df["ipc"], 12)
    ipc_dic_anterior = df["ipc"].where(df["mes"] == 12).ffill().shift(1)
    df["ipc_acumulada_anio"] = ((df["ipc"] / ipc_dic_anterior - 1) * 100).round(2)

    # Tipo de cambio
    df["tc_var_mensual"] = _var_pct(df["tipo_cambio"], 1)
    df["tc_var_interanual"] = _var_pct(df["tipo_cambio"], 12)
    # Tipo de cambio deflactado por IPC (base 100 = primer mes): >100 = el dólar
    # subió más que los precios internos (depreciación real), <100 = apreciación real.
    relacion = df["tipo_cambio"] / df["ipc"]
    base = relacion.dropna().iloc[0] if relacion.notna().any() else float("nan")
    df["tc_real_base100"] = (relacion / base * 100).round(2)
    df["brecha_tc_vs_inflacion"] = (df["tc_var_interanual"] - df["ipc_var_interanual"]).round(2)

    # Actividad
    df["emae_var_interanual"] = _var_pct(df["emae"], 12)
    return df
