"""Extracción: descarga de series desde la API de datos.gob.ar."""
from __future__ import annotations

import io
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import urlopen

import pandas as pd

from .config import API_URL, FECHA_DESDE, SERIES


def construir_url(series: dict[str, str] = SERIES, desde: str = FECHA_DESDE) -> str:
    parametros = {
        "ids": ",".join(series.values()),
        "start_date": desde,
        "collapse": "month",              # lleva la serie diaria de tipo de cambio a mensual
        "collapse_aggregation": "avg",
        "format": "csv",
        "header": "ids",
        "limit": 5000,
    }
    return f"{API_URL}?{urlencode(parametros)}"


def parsear_csv(texto: str, series: dict[str, str] = SERIES) -> pd.DataFrame:
    """CSV de la API -> DataFrame con columnas fecha, ipc, tipo_cambio, emae."""
    df = pd.read_csv(io.StringIO(texto))
    renombres = {"indice_tiempo": "fecha", **{v: k for k, v in series.items()}}
    faltantes = set(renombres) - set(df.columns)
    if faltantes:
        raise ValueError(f"La respuesta no trae las columnas esperadas: {sorted(faltantes)}")
    return df.rename(columns=renombres)[list(renombres.values())]


def descargar(series: dict[str, str] = SERIES, desde: str = FECHA_DESDE,
              timeout: int = 30) -> pd.DataFrame:
    with urlopen(construir_url(series, desde), timeout=timeout) as respuesta:
        return parsear_csv(respuesta.read().decode("utf-8"), series)


def leer_archivo(ruta: str | Path) -> pd.DataFrame:
    """Alternativa sin internet: CSV con columnas fecha, ipc, tipo_cambio, emae."""
    return pd.read_csv(ruta)
