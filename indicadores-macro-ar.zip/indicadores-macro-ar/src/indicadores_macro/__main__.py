"""Pipeline ETL completo.

    python -m indicadores_macro                      # descarga de datos.gob.ar
    python -m indicadores_macro --archivo datos.csv  # sin internet
"""
from __future__ import annotations

import argparse

from .cargar import consultar, exportar_csv, guardar_sqlite
from .config import FECHA_DESDE
from .extraer import descargar, leer_archivo
from .transformar import calcular_indicadores, limpiar, validar


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="ETL de indicadores macroeconómicos argentinos.")
    parser.add_argument("--desde", default=FECHA_DESDE)
    parser.add_argument("--archivo", help="CSV local en lugar de la API")
    parser.add_argument("--db", default="indicadores.db")
    parser.add_argument("--salida", default="salida/powerbi")
    args = parser.parse_args(argv)

    crudo = leer_archivo(args.archivo) if args.archivo else descargar(desde=args.desde)
    print(f"Extraídas {len(crudo)} filas")

    limpio = limpiar(crudo)
    for advertencia in validar(limpio):
        print(f"  [calidad] {advertencia}")
    final = calcular_indicadores(limpio)

    con = guardar_sqlite(final, args.db)
    print("\nResumen anual:")
    print(consultar(con, "v_resumen_anual").to_string(index=False))
    archivos = exportar_csv(con, args.salida)
    print(f"\n{len(archivos)} CSV exportados a {args.salida}")


if __name__ == "__main__":
    main()
