"""ETL de indicadores macroeconómicos argentinos (IPC, tipo de cambio, EMAE)."""
