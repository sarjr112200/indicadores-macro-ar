# Indicadores macroeconómicos de Argentina: pipeline ETL

![tests](https://github.com/USUARIO/indicadores-macro-ar/actions/workflows/tests.yml/badge.svg)

Pipeline **ETL en Python** que descarga series oficiales de la [API de Series de Tiempo de datos.gob.ar](https://datos.gob.ar/series), las limpia y valida, calcula indicadores económicos, las guarda en **SQLite** con vistas **SQL** analíticas y exporta CSV para un **dashboard en Power BI**.

| Serie | Fuente | Frecuencia |
|---|---|---|
| IPC Nacional nivel general | INDEC | Mensual |
| Tipo de cambio de referencia Com. A3500 | BCRA | Diaria, promediada a mensual |
| EMAE (actividad económica) | INDEC | Mensual |

## Qué calcula

- **Inflación:** variación mensual, interanual y acumulada en el año.
- **Tipo de cambio:** variación mensual e interanual.
- **Tipo de cambio real (base 100):** tipo de cambio deflactado por IPC. Muestra si el dólar subió más o menos que los precios internos.
- **Brecha dólar vs. inflación:** diferencia entre la suba interanual del dólar y la del IPC.
- **Actividad:** variación interanual del EMAE.

## Vistas SQL

| Vista | Qué responde | Técnicas |
|---|---|---|
| `v_resumen_anual` | Inflación y depreciación dic/dic, TC promedio y actividad por año | Agregación condicional con `CASE` |
| `v_top3_meses_inflacion` | Los 3 meses de mayor inflación de cada año | `ROW_NUMBER() OVER (PARTITION BY ...)` |
| `v_tc_vs_inflacion` | ¿El dólar le ganó a la inflación en los últimos 12 meses? | `CASE`, filtros |

## Calidad de datos

La etapa de limpieza convierte los tipos, lleva las fechas a inicio de mes, elimina duplicados, invalida valores ≤ 0 y **completa los meses faltantes** para que los cálculos interanuales no se desplacen. Además, `validar()` informa los problemas que encuentra (meses faltantes, nulos por serie).

## Cómo correrlo

```bash
pip install -r requirements.txt
PYTHONPATH=src python -m indicadores_macro                  # descarga desde la API (2017 en adelante)
PYTHONPATH=src python -m indicadores_macro --desde 2020-01-01
PYTHONPATH=src python -m indicadores_macro --archivo datos.csv   # sin internet
pytest -v                                                    # 15 tests
```

Los resultados quedan en `indicadores.db` y `salida/powerbi/*.csv`.

> Los IDs de las series están en `src/indicadores_macro/config.py`. Si el organismo cambia alguno, se busca el nuevo en datos.gob.ar/series y se reemplaza ahí.

## Tests

Los tests usan series **sintéticas con crecimientos exactos** (IPC +2 % mensual, dólar +3 %, EMAE +0,5 %). Así cada resultado se puede verificar a mano: por ejemplo, la inflación interanual tiene que dar 1,02¹² − 1 = 26,82 %. La descarga se prueba sin red reemplazando la conexión por una respuesta simulada.

## Dashboard sugerido (Power BI)

1. Importar `indicadores_mensuales.csv` y `v_resumen_anual.csv`.
2. **Tarjetas:** última inflación mensual, interanual y tipo de cambio.
3. **Gráfico combinado:** inflación interanual vs. variación interanual del dólar.
4. **Línea:** tipo de cambio real base 100.
5. **Barras:** inflación anual por año.
6. **Segmentador** de año.

Medidas DAX de ejemplo:

```DAX
Última inflación mensual =
    LASTNONBLANKVALUE(indicadores_mensuales[fecha], MAX(indicadores_mensuales[ipc_var_mensual]))

Inflación promedio del período = AVERAGE(indicadores_mensuales[ipc_var_mensual])
```

## Estructura

```
src/indicadores_macro/
    config.py        # IDs de series y URL de la API
    extraer.py       # descarga y parseo
    transformar.py   # limpieza, validación e indicadores
    cargar.py        # SQLite + exportación CSV
    __main__.py      # orquesta el pipeline
sql/vistas.sql       # vistas analíticas
tests/               # 15 tests con pytest
```
