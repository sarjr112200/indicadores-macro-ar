import pandas as pd
import pytest


@pytest.fixture
def series_sinteticas():
    """36 meses con crecimientos exactos para poder verificar los cálculos a mano.

    IPC crece 2 % mensual, tipo de cambio 3 % mensual, EMAE 0,5 % mensual.
    """
    fechas = pd.date_range("2022-01-01", periods=36, freq="MS")
    t = range(36)
    return pd.DataFrame({
        "fecha": fechas.strftime("%Y-%m-%d"),
        "ipc": [100 * 1.02 ** i for i in t],
        "tipo_cambio": [50 * 1.03 ** i for i in t],
        "emae": [140 * 1.005 ** i for i in t],
    })
