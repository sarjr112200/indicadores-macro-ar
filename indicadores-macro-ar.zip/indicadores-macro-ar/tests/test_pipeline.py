import io

import numpy as np
import pandas as pd
import pytest

from indicadores_macro import extraer
from indicadores_macro.__main__ import main
from indicadores_macro.cargar import consultar, exportar_csv, guardar_sqlite
from indicadores_macro.config import SERIES
from indicadores_macro.transformar import calcular_indicadores, limpiar, validar

INTERANUAL_2PCT = round((1.02 ** 12 - 1) * 100, 2)   # 26.82
INTERANUAL_3PCT = round((1.03 ** 12 - 1) * 100, 2)   # 42.58


# ---------- Extracción ----------

def test_construir_url_incluye_parametros():
    url = extraer.construir_url(desde="2020-01-01")
    for serie in SERIES.values():
        assert serie in url
    assert "collapse=month" in url and "start_date=2020-01-01" in url and "format=csv" in url


def test_parsear_csv_renombra_columnas():
    texto = (f"indice_tiempo,{SERIES['ipc']},{SERIES['tipo_cambio']},{SERIES['emae']}\n"
             "2024-01-01,100,800,150\n")
    df = extraer.parsear_csv(texto)
    assert list(df.columns) == ["fecha", "ipc", "tipo_cambio", "emae"]


def test_parsear_csv_columnas_faltantes():
    with pytest.raises(ValueError, match="columnas esperadas"):
        extraer.parsear_csv("indice_tiempo,otra\n2024-01-01,1\n")


def test_descargar_sin_red(monkeypatch):
    texto = (f"indice_tiempo,{SERIES['ipc']},{SERIES['tipo_cambio']},{SERIES['emae']}\n"
             "2024-01-01,100,800,150\n")

    class RespuestaFalsa(io.BytesIO):
        def __enter__(self): return self
        def __exit__(self, *a): pass

    monkeypatch.setattr(extraer, "urlopen", lambda url, timeout: RespuestaFalsa(texto.encode()))
    assert len(extraer.descargar()) == 1


# ---------- Transformación ----------

def test_limpiar_corrige_tipos_duplicados_y_huecos():
    crudo = pd.DataFrame({
        "fecha": ["2024-01-01", "2024-02-15", "2024-02-01", "2024-04-01", "basura", None],
        "ipc": ["100", "105", "104", "110", "1", None],
        "tipo_cambio": [800, 820, 830, -5, 1, None],
        "emae": [150, 151, 152, 153, 1, None],
    })
    df = limpiar(crudo)
    assert df["fecha"].dt.strftime("%Y-%m").tolist() == ["2024-01", "2024-02", "2024-03", "2024-04"]
    assert df.loc[1, "ipc"] == 104  # duplicado de febrero: queda el último
    assert np.isnan(df.loc[2, "ipc"])  # marzo faltante se completa con NaN
    assert pd.isna(df.loc[3, "tipo_cambio"])  # valor negativo invalidado
    assert "Faltan meses" not in " ".join(validar(df))
    assert "tipo_cambio: 2 valores faltantes" in validar(df)


def test_validar_serie_completa_sin_advertencias(series_sinteticas):
    assert validar(limpiar(series_sinteticas)) == []


def test_variaciones(series_sinteticas):
    df = calcular_indicadores(limpiar(series_sinteticas))
    assert df["ipc_var_mensual"].dropna().eq(2.0).all()
    assert df["ipc_var_interanual"].dropna().eq(INTERANUAL_2PCT).all()
    assert df["tc_var_interanual"].dropna().eq(INTERANUAL_3PCT).all()
    assert df["emae_var_interanual"].dropna().round(2).eq(round((1.005 ** 12 - 1) * 100, 2)).all()


def test_inflacion_acumulada_en_el_anio(series_sinteticas):
    df = calcular_indicadores(limpiar(series_sinteticas)).set_index("fecha")
    assert df.loc["2023-03-01", "ipc_acumulada_anio"] == round((1.02 ** 3 - 1) * 100, 2)
    assert df.loc["2023-12-01", "ipc_acumulada_anio"] == INTERANUAL_2PCT
    assert np.isnan(df.loc["2022-06-01", "ipc_acumulada_anio"])  # no hay diciembre previo


def test_tipo_de_cambio_real(series_sinteticas):
    df = calcular_indicadores(limpiar(series_sinteticas))
    assert df["tc_real_base100"].iloc[0] == 100.0
    # El dólar sube 3 % y los precios 2 %: depreciación real creciente
    assert df["tc_real_base100"].is_monotonic_increasing
    assert (df["brecha_tc_vs_inflacion"].dropna() > 0).all()


# ---------- Carga ----------

@pytest.fixture
def con(series_sinteticas, tmp_path):
    return guardar_sqlite(calcular_indicadores(limpiar(series_sinteticas)), tmp_path / "t.db")


def test_resumen_anual(con):
    df = consultar(con, "v_resumen_anual")
    assert df["anio"].tolist() == [2022, 2023, 2024]
    assert pd.isna(df.loc[0, "inflacion_anual_pct"])  # 2022 no tiene diciembre previo
    assert df.loc[1, "inflacion_anual_pct"] == INTERANUAL_2PCT
    assert df.loc[2, "depreciacion_anual_pct"] == INTERANUAL_3PCT
    assert df["meses_con_datos"].tolist() == [12, 12, 12]


def test_top3_meses(con):
    df = consultar(con, "v_top3_meses_inflacion")
    assert df.groupby("anio").size().tolist() == [3, 3, 3]
    assert df["puesto"].tolist()[:3] == [1, 2, 3]


def test_tc_vs_inflacion(con):
    df = consultar(con, "v_tc_vs_inflacion")
    assert len(df) == 24
    assert set(df["lectura"]) == {"depreciación real"}


def test_vista_inexistente(con):
    with pytest.raises(KeyError):
        consultar(con, "v_no_existe")


def test_exportar_csv(con, tmp_path):
    archivos = exportar_csv(con, tmp_path / "pbi")
    assert len(archivos) == 4 and all(a.stat().st_size > 0 for a in archivos)


def test_pipeline_completo_desde_archivo(series_sinteticas, tmp_path, capsys):
    archivo = tmp_path / "datos.csv"
    series_sinteticas.to_csv(archivo, index=False)
    main(["--archivo", str(archivo), "--db", str(tmp_path / "x.db"), "--salida", str(tmp_path / "s")])
    salida = capsys.readouterr().out
    assert "Extraídas 36 filas" in salida
    assert (tmp_path / "s" / "v_resumen_anual.csv").exists()
