-- Vistas analíticas sobre la tabla indicadores_mensuales.

DROP VIEW IF EXISTS v_resumen_anual;
CREATE VIEW v_resumen_anual AS
-- Inflación y depreciación anual (dic contra dic), tipo de cambio promedio y actividad.
SELECT anio,
       MAX(CASE WHEN mes = 12 THEN ipc_var_interanual END) AS inflacion_anual_pct,
       ROUND(AVG(tipo_cambio), 2)                          AS tc_promedio,
       MAX(CASE WHEN mes = 12 THEN tc_var_interanual END)  AS depreciacion_anual_pct,
       ROUND(AVG(emae_var_interanual), 2)                  AS emae_var_promedio_pct,
       COUNT(ipc)                                          AS meses_con_datos
FROM indicadores_mensuales
GROUP BY anio
ORDER BY anio;

DROP VIEW IF EXISTS v_top3_meses_inflacion;
CREATE VIEW v_top3_meses_inflacion AS
-- Los 3 meses de mayor inflación mensual de cada año (función de ventana por partición).
SELECT anio, puesto, fecha, ipc_var_mensual
FROM (
    SELECT anio,
           fecha,
           ipc_var_mensual,
           ROW_NUMBER() OVER (PARTITION BY anio ORDER BY ipc_var_mensual DESC) AS puesto
    FROM indicadores_mensuales
    WHERE ipc_var_mensual IS NOT NULL
)
WHERE puesto <= 3
ORDER BY anio, puesto;

DROP VIEW IF EXISTS v_tc_vs_inflacion;
CREATE VIEW v_tc_vs_inflacion AS
-- Mes a mes: ¿el dólar le ganó o le perdió a la inflación en los últimos 12 meses?
SELECT fecha,
       ipc_var_interanual,
       tc_var_interanual,
       brecha_tc_vs_inflacion,
       tc_real_base100,
       CASE WHEN brecha_tc_vs_inflacion > 0 THEN 'depreciación real'
            WHEN brecha_tc_vs_inflacion < 0 THEN 'apreciación real'
            ELSE 'neutral'
       END AS lectura
FROM indicadores_mensuales
WHERE brecha_tc_vs_inflacion IS NOT NULL
ORDER BY fecha;
